//
//  CommunityMainScreen.swift
//  CalorieSnap
//
//  Created by Steph on 6/12/2024.
//

import UIKit

class CommunityViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        title = "Community"
    }
}
